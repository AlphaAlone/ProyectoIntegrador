/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author renemendez
 */
public class Login extends Application {
 
    @FXML

    @Override
    public void start(Stage stage) throws Exception {
        
     
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
         stage.setTitle("Semaforo Inteligente");
        stage.show();
    }
     public boolean login(String usser, String password){
        try{
            MySQLConnection con = new MySQLConnection().obtener();
            ResultSet resultado = con.cosulta("SELECT name FROM usser WHERE name = '" + usser + "' AND password = '" + password + "'");
            resultado.last();
            if(resultado.getRow() > 0){
                return true;
            }
        }catch(SQLException e){
            e.printStackTrace();
            return false;
        }
        return false;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
