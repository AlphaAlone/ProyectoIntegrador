/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;
/**
 *45-20+1)
 * @author renemendez
 */
   import java.util.Observable;
public class Valores  extends Observable{
    
    int valor;
    String numCadena;
    public void val(){
        for(int i=0;i<20;i++){
            valor=(int)Math.floor(Math.random()*100);
            numCadena= valor+"";
        }
    }
    public String getValor(){
        return numCadena;
    }

    String getVaslor() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
