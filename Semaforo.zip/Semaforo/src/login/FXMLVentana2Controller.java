/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author renemendez
 */
public class FXMLVentana2Controller implements Initializable {

    @FXML
    private Button btnAcerca;
    @FXML
    private Button btnsensor;
    @FXML
    private Button btnsensor2;
    @FXML
    private Button btnsensor3;
    @FXML
    private Button btnsensor4;
    @FXML
    private Button closebtn;
    @FXML
    private Button btnluces;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    


    @FXML
    private void Acerca(ActionEvent event) throws IOException {  
      FXMLLoader loader = new FXMLLoader();
        loader.setLocation(FXMLDocumentController.class.getResource("FXMLAcerca.fxml"));
        
        Parent Acerca = (Parent) loader.load();
        
        Scene scene2 = new Scene(Acerca);
        
        Stage s2 = new Stage();
        s2.setScene(scene2);
        s2.show();

    }

    @FXML
    private void sensor(ActionEvent event) throws IOException {
          FXMLLoader loader = new FXMLLoader();
        loader.setLocation(FXMLDocumentController.class.getResource("FXMLsensor.fxml"));
        
        Parent sensor = (Parent) loader.load();
        
        Scene scene2 = new Scene(sensor);
        
        Stage s2 = new Stage();
        s2.setScene(scene2);
        s2.show();
        
        
    }

    @FXML
    private void sensor2(ActionEvent event) throws IOException {
          FXMLLoader loader = new FXMLLoader();
        loader.setLocation(FXMLDocumentController.class.getResource("FXMLsensor2.fxml"));
        
        Parent sensor2= (Parent) loader.load();
        
        Scene scene2 = new Scene(sensor2);
        
        Stage s2 = new Stage();
        s2.setScene(scene2);
        s2.show();
    }

    @FXML
    private void sensor3(ActionEvent event) throws IOException {
          FXMLLoader loader = new FXMLLoader();
        loader.setLocation(FXMLDocumentController.class.getResource("FXMLsensor3.fxml"));
        
        Parent sensor3 = (Parent) loader.load();
        
        Scene scene2 = new Scene(sensor3);
        
        Stage s2 = new Stage();
        s2.setScene(scene2);
        s2.show();
    }

    @FXML
    private void sensor4(ActionEvent event) throws IOException {
          FXMLLoader loader = new FXMLLoader();
        loader.setLocation(FXMLDocumentController.class.getResource("FXMLsensor4.fxml"));
        
        Parent sensor4 = (Parent) loader.load();
        
        Scene scene2 = new Scene(sensor4);
        
        Stage s2 = new Stage();
        s2.setScene(scene2);
       
        s2.show();
    }

    @FXML
    private void close(ActionEvent event) throws IOException {
          Stage stage = (Stage) this.closebtn.getScene().getWindow();
        
        Parent root = FXMLLoader.load(getClass().getResource("FXMLVentana2.fxml"));
       // JOptionPane.showMessageDialog(null,"Cerrando Sesion");
        stage.close();
        
    }

    @FXML
    private void luces(ActionEvent event) throws IOException {
        
           FXMLLoader loader = new FXMLLoader();
        loader.setLocation(FXMLDocumentController.class.getResource("FXMLluces.fxml"));
        
        Parent sensor4 = (Parent) loader.load();
        
        Scene scene2 = new Scene(sensor4);
        
        Stage s2 = new Stage();
        s2.setScene(scene2);
       
        s2.show();
    }
    
}
