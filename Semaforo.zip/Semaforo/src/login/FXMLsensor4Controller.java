/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
/**
 * FXML Controller class
 *
 * @author renemendez
 */
public class FXMLsensor4Controller implements Initializable {

    @FXML
    private Button btnactivarsensor;
    @FXML
    private ListView<String> list;
    @FXML
    private LineChart<?,?> grafica;
    private Object series;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void activarsensor(ActionEvent event) throws InterruptedException {   
        Valores Val= new Valores();    
        for(int i=0;i<7;i++){
        Val.val();
        String Valor= Val.getValor();
        list.getItems().add(Valor);
       /* grafica.getData().addAll(Valor);*/
        } 
        final NumberAxis xAxis= new NumberAxis();
        final NumberAxis yAxis= new NumberAxis();
        xAxis.setLabel("number of month");
        final LineChart<Number,Number> lineChart = 
                new LineChart<Number,Number>(xAxis,yAxis);
                
        lineChart.setTitle("Sensor");
  
        XYChart.Series series = new XYChart.Series();
        series.setName("My portfolio");
       
        series.getData().add(new XYChart.Data(1, 22));
        series.getData().add(new XYChart.Data(2, 14));
        series.getData().add(new XYChart.Data(3, 15));
        series.getData().add(new XYChart.Data(4, 24));
        series.getData().add(new XYChart.Data(5, 34));
        series.getData().add(new XYChart.Data(6, 36));
        series.getData().add(new XYChart.Data(7, 22));
        series.getData().add(new XYChart.Data(8, 45));
        series.getData().add(new XYChart.Data(9, 43));
        series.getData().add(new XYChart.Data(10, 17));
        series.getData().add(new XYChart.Data(11, 29));
        series.getData().add(new XYChart.Data(12, 25));
    }
 
    public static void main(String[] args) {
    }
}
       /* series.getData().add(new XYChart.Data(1,Valor));*/
        
       /*
       int num1=50;
        int num2=120;
 
        System.out.println("Números generados entre 0 y 20, con decimales (sin incluir el 0 y el 20)");
        for (int i=0;i<1000;i++){
            double numAleatorio=Math.random()*20;
            System.out.println(numAleatorio);
        }
 
        System.out.println("Números generados entre 5 y 20, con decimales (sin incluir el 5 y el 20)");
        for (int i=0;i<1000;i++){
            double numAleatorio=Math.random()*(20-5)+5;
            System.out.println(numAleatorio);
        }
 
        System.out.println("Números generados entre 50 y 120, sin decimales (sin incluir el 50 y el 120)");
        for (int i=0;i<1000;i++){
            int numAleatorio=(int)Math.floor(Math.random()*(num1-num2)+num2);
            System.out.println(numAleatorio);
        }
 
                System.out.println("Números generados entre 50 y 120, sin decimales (incluyendo el 50 y el 120)");
        for (int i=0;i<1000;i++){
            int numAleatorio=(int)Math.floor(Math.random()*(num1-(num2+1))+(num2));
            System.out.println(numAleatorio);     
        }*/


     
    

