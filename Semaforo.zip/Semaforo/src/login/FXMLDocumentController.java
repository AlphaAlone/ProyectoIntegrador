/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * @author renemendez
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private Button entrar;
    @FXML
    private TextField usu;
    @FXML
    private PasswordField pas;
    private Object controller;
    @FXML
   
    
    
    private void handleButtonAction(ActionEvent event) throws IOException {
        
        
        String Usuario="admin";
        String contraseña="123";
        String user;
        String pass;
        
        user=usu.getText();
        pass=pas.getText();
        
        if(usu.getText().equals(Usuario)&&pas.getText().equals(contraseña))
        {
          FXMLLoader loader = new FXMLLoader();
        loader.setLocation(FXMLDocumentController.class.getResource("FXMLVentana2.fxml"));
        
        Parent ventana2 = (Parent) loader.load();
        
        Scene scene2 = new Scene(ventana2);
        
        Stage s2 = new Stage();
        s2.setScene(scene2);
        s2.show();
        }
        
      /* else
        {
            Error p= new Error();
            p.setVisible(true);
            dispose();
        }
                
      /*  FXMLLoader loader = new FXMLLoader();
        loader.setLocation(FXMLDocumentController.class.getResource("FXMLVentana2.fxml"));
        
        Parent ventana2 = (Parent) loader.load();
        
        Scene scene2 = new Scene(ventana2);
        
        Stage s2 = new Stage();
        s2.setScene(scene2);
        s2.show();
       */
        
    }
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    private void dispose() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
