/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;

/**
 * FXML Controller class
 *
 * @author renemendez
 */
public class FXMLsensor3Controller implements Initializable {

    @FXML
    private Button btnsensoractivacion;
    @FXML
    private ListView<String> list;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void activacion(ActionEvent event) throws InterruptedException{
        
         Valores Val= new Valores();
        
       
       
         for(int i=0;i<15;i++){
        Val.val();
        String Valor= Val.getValor();
        list.getItems().add(Valor);
        }
        
    }
}
    
 
