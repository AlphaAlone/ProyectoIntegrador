package login;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;
import java.sql.*;
/**
 *
 * @author renemendez
 */
public class MySQLConnection {
    private String user;
    private String password;
    private Connection con;
    
    public MySQLConnection(){
        this.con = setConnection();
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    private Connection setConnection(){
        String url = "jdbc:mysql://localhost:3306/testjava";
        try{
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection(url, "root", "root1234");
            return con;
        }catch(Exception e){
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos");
            return null;
        }
        
    }

    ResultSet cosulta(String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    MySQLConnection obtener() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Connection getConnection() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
