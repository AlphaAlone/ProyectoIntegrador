/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;
/**
 *45-20+1)
 * @author renemendez
 */
   import java.util.Observable;
public class valores1 extends Observable{
    
    int val;
    String numCadena;
    public void vala(){
        for(int i=0;i<20;i++){
            val=(int)Math.floor(Math.random()*40);
            numCadena= val+"";
        }
    }
    public String getValor(){
        return numCadena;
    }

    String getVaslor() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    String getvalor1() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    String getvalo() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
