/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 *
 * @author Dinamita
 */
public class recopilacionDatos {
    private final MySQLConnection con = new MySQLConnection().obtener();
    private final Connection conDB = con.getConnection();
    private PreparedStatement pS;
    private ResultSet rs;
    private String nomArchivo;
    
    public recopilacionDatos(){
    }
    
    public void escribir(int hum, int temp, int movi, int humo){
        String insertar = "INSERT INTO sensores" 
                + "(Semaforo 1, Semaforo 2, Semaforo 3, Semaforo 4) VALUES"
                + "(?,?,?,?);";
        
        try{
            pS = conDB.prepareStatement(insertar);
            
            pS.setInt(1, hum);
            pS.setInt(2, temp);
            pS.setInt(3, movi);
            pS.setInt(4, humo);
            
            pS.executeUpdate();
            System.out.println("Record is inserted into DBUSER table!");
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }
    
    public void getTable(String tab){
        switch(tab){
            case "Semaforo 1":
                nomArchivo = "Semaforo 1";
                break;
            case "Semaforo 2":
                nomArchivo = "Semaforo 2";
                break;
            case "Semaforo 3":
                nomArchivo = "Semaforo 3";
                break;
            case "Semaforo 4":
                nomArchivo = "Semaforo 4";
                break;
        }
    }
    
    public String setNTable(){
        return nomArchivo;
    }
    
    public ResultSet setTable(){
        return rs = con.cosulta("SELECT " +nomArchivo+ " FROM sensores;");
    }
    
}
